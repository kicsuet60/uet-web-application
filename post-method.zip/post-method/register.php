<?php
if (isset($_POST['submit'])) {

    if (!empty($_POST['name'] && $_POST['email'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        echo "<h1>Greating to $name! And Email $email</h1>";
    } else {
        echo "Hey' Empty fields, Go Back To Login!";
    }
} else {
    echo "You are not authorised!";
}
