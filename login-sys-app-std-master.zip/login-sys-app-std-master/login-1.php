<?php
ob_start();
session_start();
if (isset($_SESSION['login'])) {
	header("Location: index.php");
}
?>
<?php $currentPage = "Login"; ?>
<?php require_once('includes/header.php') ?>
<?php
//google recaptcha
$public_key = "6Lf24t0cAAAAAJjeZqUvBh8k2BTX6PjHrq6rSMoH";
$private_key = "6Lf24t0cAAAAAMoqQcbREASAtQrk5j8_QlS00Vt6";
$url = "https://www.google.com/recaptcha/api/siteverify";

if (isset($_POST['resend'])) {
	if (!isset($_COOKIE['_resend_'])) {
		$user_name = escape($_POST['user_name']);
		$user_email = escape($_POST['user_email']);

		date_default_timezone_set("asia/karachi");

		$mail->addAddress($_POST['user_email']);
		$token = getToken(32);
		$email = base64_encode(urlencode($_POST['user_email']));
		$expire_date = date("Y-m-d H:i:s", time() + 60 * 20);
		$expire_date = base64_encode(urlencode($expire_date));

		$query = "UPDATE users SET validation_key = '$token' WHERE user_name = '$user_name' AND user_email = '$user_email' AND is_active = 0";
		$query_con = mysqli_query($connection, $query);
		if (!$query_con) {
			die("Query Failed" . mysqli_error($connection));
		} else {
			$mail->Subject = "Verify your email";
			$mail->Body = "
                                        <h2>Follow the link to verify</h2>
                                        <a href='http://localhost/login-sys-app-2/activation.php?eid={$email}&token={$token}&&exd={$expire_date}'>Click here to verify</a>
                                        <p>This link is self terminate in next 20 minutes</p>
                                        ";

			if ($mail->send()) {
				setcookie('_resend_', getToken(16), time() + 60 * 20, '', '', '', true);
				$checkEmail = "<div class='alert alert-primary'><h4>Check your email for activation link</h4></div>";
			}
		}
	} else {
		$userStay = "<div class='alert alert-warning'><h4>Your request not entertain befor 20 minuts, Stay Cool!</h4></div>";
	}
}


if (isset($_POST['login'])) {

	$response_key = $_POST['g-recaptcha-response'];

	$response = file_get_contents($url . "?secret=" . $private_key . "&response=" . $response_key . "&remoteip=" . $_SERVER['REMOTE_ADDR']);
	$response = json_decode($response);

	if (!($response->success == 1)) {
		$errCaptcha = "Wrong captcha";
	}

	$user_name = escape($_POST['user_name']);

	$user_email = escape($_POST['user_email']);
	$user_password = escape($_POST['user_password']);

	$query = "SELECT * FROM users WHERE user_name = '$user_name' AND user_email = '$user_email'";
	$query_con = mysqli_query($connection, $query);

	if (!$query_con) {
		die("Query Failed" . mysqli_error($connection));
	}

	$result = mysqli_fetch_assoc($query_con);

	if (!$result) {
		if (!isset($errCaptcha)) {

			$_SESSION['toastr'] = array(
				'type'      => 'error',
				'message' => 'Required Signup! Go to Register Page',
				'title'     => 'No Result Found'
			);
		}
	} else {
		if (password_verify($user_password, $result['user_password'])) {

			//echo "Success";
			if ($result['is_active'] == 1) {

				if (!isset($errCaptcha)) {
					$_SESSION['toastr'] = array(
						'type'      => 'success',
						'message' => 'Log In Successfull !',
						'title'     => 'Log In'
					);
					$_SESSION['login'] = 'success';
					header("Refresh:3;url=index.php");
				}
			} else {
				if (!isset($errCaptcha)) {


					$errVerify = "<div class='alert alert-danger'><h4>You are not verified user</h4> <form method='POST'><input type='text' value={$user_name} name='user_name' hidden><input text='email' value={$user_email} name='user_email' hidden><bresendon class='resend fxt-btn-fill' class type='submit' value='' name='resend'>Click to Verify</button></form></div>";

					$_SESSION['toastr'] = array(
						'type'      => 'error',
						'message' => 'Please verfying with email!',
						'title'     => 'Verfication Required!'
					);
				}
			}
		} else {
			$_SESSION['toastr'] = array(
				'type'      => 'error',
				'message' => 'Password not Match, Contact with Web Master',
				'title'     => 'Password not Match!'
			);
		}
	}
}

?>
<section class="fxt-template-animation fxt-template-layout1">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-12 fxt-bg-color">
				<div class="fxt-content">
					<div class="fxt-header">
						<a href="index.php" class="fxt-logo"><img src="img/logo-1.png" alt="Logo"></a>
						<div class="fxt-page-switcher">
							<a href="login-1.php" class="switcher-text1 active">Log In</a>
							<a href="register-1.php" class="switcher-text1">Register</a>
						</div>
					</div>
					<div class="fxt-form">
						<?php
						if (isset($errVerify)) {
							echo $errVerify;
						}

						if (isset($checkEmail)) {
							echo $checkEmail;
						}

						if (isset($userStay)) {
							echo $userStay;
						}

						?>
						<h2>Log In</h2>
						<p>Log in to continue in our website</p>
						<form action="login-1.php" method="POST">
							<div class="form-group">
								<div class="fxt-transformY-50 fxt-transition-delay-1">
									<input type="text" class="form-control" name="user_name" placeholder="Username" required="required">
									<i class="flaticon-user"></i>
								</div>
							</div>
							<div class="form-group">
								<div class="fxt-transformY-50 fxt-transition-delay-2">
									<input type="email" class="form-control" name="user_email" placeholder="Email Address" required="required">
									<i class="flaticon-envelope"></i>
								</div>
							</div>
							<div class="form-group">
								<div class="fxt-transformY-50 fxt-transition-delay-3">
									<input type="password" class="form-control" name="user_password" placeholder="Password" required="required">
									<i class="flaticon-padlock"></i>
								</div>
							</div>
							<div class="form-group">
								<div class="fxt-transformY-50 fxt-transition-delay-4">
									<div class="fxt-checkbox-area">
										<div class="checkbox">
											<input id="remember-me" class="remember-me" type="checkbox" name="remember-me">
											<label for="remember-me">Keep me logged in</label>
										</div>
									</div>
								</div>
							</div>
							<div class="g-recaptcha fxt-transformY-50 fxt-transition-delay-5 mt-4" data-sitekey="<?php echo $public_key; ?>"></div>
							<?php echo isset($errCaptcha) ? "<span class='error mb-2 mt-1'>{$errCaptcha}</span>" : ""; ?>
							<div class="form-group">
								<div class="fxt-transformY-50 fxt-transition-delay-6">
									<div class="">
										<button type="submit" name="login" class="fxt-btn-fill">Log in</button>
										<span><a href="forgot-password-1.php" class="switcher-text2 forgot-password text-right d-inline float-right" style="line-height: 75px;">Forgot Password</a></span>
									</div>
								</div>
							</div>
						</form>
					</div>

					<div class="fxt-footer">
						<ul class="fxt-socials">
							<li class="fxt-facebook fxt-transformY-50 fxt-transition-delay-7">
								<a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
							</li>
							<li class="fxt-twitter fxt-transformY-50 fxt-transition-delay-8">
								<a href="#" title="twitter"><i class="fab fa-twitter"></i></a>
							</li>
							<li class="fxt-google fxt-transformY-50 fxt-transition-delay-9">
								<a href="#" title="google"><i class="fab fa-google-plus-g"></i></a>
							</li>
							<li class="fxt-linkedin fxt-transformY-50 fxt-transition-delay-10">
								<a href="#" title="linkedin"><i class="fab fa-linkedin-in"></i></a>
							</li>
							<li class="fxt-pinterest fxt-transformY-50 fxt-transition-delay-11">
								<a href="#" title="pinterest"><i class="fab fa-pinterest-p"></i></a>
							</li>
						</ul>
						<h5 class="mt-4 fxt-transformY-50 fxt-transition-delay-12"">Tahir <span style=" color:red;">Shafi</span> &nbsp;&nbsp;&nbsp;<i class="fa fa-mobile"></i> +92 334 1068 817</h5>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-12 fxt-none-767 fxt-bg-img" data-bg-image="img/figure/bg1-l.jpg"></div>
		</div>
	</div>
</section>
<?php require_once('includes/footer.php') ?>