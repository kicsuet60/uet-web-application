<?php
ob_start();
session_start();
?>
<?php $currentPage = "Home"; ?>
<?php require_once('includes/header.php') ?>
<style>
    .wrap {
        display: grid;
        justify-items: center;
        background-color: #f5f7f8;
        max-width: 100%;
    }

    .wrap .banner {
        display: grid;
        grid-template-columns: 60% 1fr;
        max-width: 85%;
        min-height: 100vh;
        padding-top: 100px;
        box-sizing: border-box;
    }

    .wrap .banner .banner-left img {
        max-width: 100%;
        height: auto;
    }

    .wrap .banner .banner-right {
        text-align: center;
        padding-top: 50px;
    }

    .wrap .banner .banner-right .btn-wrap {
        align-content: center;
    }

    .wrap .banner .banner-right .btn-wrap .btn {
        display: inline-block;
        width: 40%;
        padding: 0 20px;
    }

    .wrap .banner .banner-right .btn-wrap .btn a {
        display: inline-block;
        width: 100%;
        text-decoration: none;
        border: none;
        color: #fff;
        padding: 12px;
        border-radius: 25px;
        box-shadow: 0 0 8px 1px rgba(56, 53, 68, 0.2);
        transition: all 0.3s;
    }

    .wrap .banner .banner-right .btn-wrap .btn.download-btn a {
        background-color: #0099d8;
    }

    .wrap .banner .banner-right .btn-wrap .btn.download-btn a:hover {
        box-shadow: 2px 2px 10px 1px rgba(56, 53, 68, 0.4);
        background-color: #0087bf;
    }

    .wrap .banner .banner-right .btn-wrap .btn.demo-btn a {
        background-color: #383544;
    }

    .wrap .banner .banner-right .btn-wrap .btn.demo-btn a:hover {
        box-shadow: 2px 2px 10px 1px rgba(56, 53, 68, 0.4);
        background-color: #2c2a36;
    }

    .wrap .banner .description {
        grid-column: 1/-1;
        text-align: center;
        font-size: 1.5rem;
        padding: 0 50px;
    }

    .wrap .banner .description .notice {
        font-size: 12px;
    }

    .wrap .feature-section {
        display: grid;
        grid-template-columns: repeat(3, minmax(auto, 300px));
        justify-content: center;
        grid-gap: 25px;
        justify-self: stretch;
        padding: 80px 0;
        background-color: #f0fbff;
    }

    .wrap .feature-section h2 {
        font-size: 2rem;
        margin: 0 0 40px;
        text-align: center;
        grid-column: 1/-1;
        color: #383544;
    }

    .wrap .feature-section .feature {
        background-color: rgba(255, 255, 255, 0.4);
        text-align: center;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 50px;
        box-shadow: 0 0 15px 0.5px rgba(56, 53, 68, 0.1);
        transition: box-shadow 0.3s;
        position: relative;
    }

    .wrap .feature-section .feature i {
        position: absolute;
        width: 42px;
        height: 42px;
        top: -35px;
        left: 0;
        right: 0;
        margin: 0 auto;
        border-radius: 50%;
        box-shadow: 0 3px 15px 2px rgba(0, 0, 0, 0.2);
        padding: 8px;
        color: #0099d8;
        background-color: #fff;
        font-size: 2.5rem;
    }

    .wrap .feature-section .get-involved {
        grid-column: 1/-1;
        text-align: center;
    }

    .wrap .feature-section .get-involved a {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        background-color: #383544;
        padding: 15px 30px;
        border-radius: 25px;
        margin: 20px 0;
        box-shadow: 0 0 8px 1px rgba(56, 53, 68, 0.5);
        transition: all 0.3s;
    }

    .wrap .feature-section .get-involved a:hover {
        box-shadow: 2px 2px 10px 1px rgba(56, 53, 68, 0.8);
        background-color: #2c2a36;
    }

    .wrap .feature-section .get-involved a i {
        vertical-align: middle;
    }

    .wrap .cta {
        text-align: center;
    }

    .wrap .cta .cta-btn {
        padding: 150px 0;
    }

    .wrap .cta .cta-btn p {
        font-size: 2.5rem;
        margin: 0;
    }

    .wrap .cta .cta-btn a {
        display: inline-block;
        font-size: 1.5rem;
        text-decoration: none;
        color: #fff;
        background-color: #0099d8;
        padding: 20px 80px;
        border-radius: 45px;
        margin: 50px 0;
        box-shadow: 0 0 8px 1px rgba(56, 53, 68, 0.5);
        transition: all 0.3s;
    }

    .wrap .cta .cta-btn a:hover {
        box-shadow: 2px 2px 10px 1px rgba(56, 53, 68, 0.6);
        background-color: #0087bf;
    }

    .wrap .cta .cta-btn .warning {
        font-size: 14px;
    }

    .wrap .cta .credit p a {
        text-decoration: none;
        color: #0099d8;
    }

    .wrap .cta .credit p i {
        color: #e80d2e;
        animation: heartbeat 3s infinite;
        vertical-align: middle;
    }

    @media (max-width: 1230px) {
        .wrap .banner {
            max-width: 100%;
        }
    }

    @media (max-width: 1040px) {
        .wrap .banner {
            padding-top: 20px;
        }

        .wrap .banner .banner-left,
        .wrap .banner .banner-right {
            grid-column: span 2;
        }

        .wrap .banner .banner-right {
            padding-top: 10px;
        }

        .wrap .banner .banner-right .btn:first-child {
            padding-left: 0;
        }

        .wrap .feature-section {
            grid-template-columns: repeat(4, 150px);
        }

        .wrap .feature-section .feature {
            grid-column: span 2;
        }

        .wrap .feature-section .get-involved {
            grid-column: span 4;
        }
    }

    @media (max-width: 742px) {
        .wrap .banner {
            padding-top: 10px;
        }

        .wrap .banner .description {
            font-size: 1.2rem;
            padding: 0 20px;
        }

        .wrap .feature-section {
            grid-template-columns: repeat(2, 200px);
        }

        .wrap .feature-section .get-involved {
            grid-column: span 2;
        }

        .wrap .cta .cta-btn {
            padding: 80px 0;
        }

        .wrap .cta .cta-btn p {
            font-size: 2em;
        }

        .wrap .cta .cta-btn a {
            padding: 15px 30px;
            font-size: 1rem;
        }
    }

    @media (max-width: 488px) {
        .wrap .banner .banner-right .btn-wrap .btn {
            width: 35%;
        }

        .wrap .feature-section {
            grid-template-columns: repeat(2, 140px);
        }

        .wrap .feature-section .get-involved {
            grid-column: span 2;
        }
    }

    @keyframes heartbeat {
        0% {
            transform: scale(1);
        }

        5% {
            transform: scale(1.3);
        }

        10% {
            transform: scale(1.1);
        }

        20% {
            transform: scale(1.5);
        }

        30% {
            transform: scale(1);
        }

        100% {
            transform: scale(1);
        }
    }
</style>
<div class="wrap">

    <section class="banner">
        <div class="banner-left">
            <img src="https://s3.us-west-1.wasabisys.com/uistore/assets/images/podcast-app-free-ui-kit-for-adobe-xd-thumb.jpg" alt="" />
        </div>
        <div class="banner-right">
            <img src="http://res.cloudinary.com/dzuqw67ww/image/upload/v1519715524/nest-128_fgdoao.png" alt="" />
            <h1>Welcome To Login System</h1>
            <h4 class="tagline">AWAD Artisians</h4>
            <?php

            if (isset($_SESSION['login'])) {
                echo "<h2>You are logged in <a href='logout.php'>Logout</a></h2>";
            } else { ?>
                <div class="btn-wrap">
                    <div class="btn download-btn">
                        <a href="http://localhost/login-sys-app-2/login-1.php">Login</a>
                    </div>
                    <div class="btn demo-btn">
                        <a target="_blank" href="http://localhost/login-sys-app-2/register-1.php">SignUp</a>
                    </div>
                </div>
            <?php
            }

            ?>

        </div>

    </section>


</div>
<?php require_once('includes/footer.php') ?>