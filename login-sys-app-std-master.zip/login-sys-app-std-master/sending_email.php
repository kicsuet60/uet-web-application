<?php
require_once("vendor/autoload.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->Host = "smtp.gmail.com";
$mail->Port = "465";
$mail->SMTPSecure = "ssl";

$mail->Username = "";
$mail->Password = "";

$mail->setFrom("");
$mail->addReplyTo("no-reply@aahadlhr.com");

// recipient
$mail->addAddress("tahirshafish@gmail.com");
$mail->isHTML();
$mail->Subject = "Sending from localhost";
$mail->Body = "
                    <div style='color: blue;font-size: 20px;background-color:grey;'>
                        Thank for your experience!!!
                    </div>
                ";

if ($mail->send()) {
    echo "Email sent";
} else {
    echo "Sorry for inconvenience";
}
