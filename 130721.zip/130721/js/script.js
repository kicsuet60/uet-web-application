$(function () {
    // $(".red-box").fadeOut(2000);
    // $(".red-box").fadeOut();
    // $(".red-box").fadeOut("slow");
    // $(".red-box").fadeOut("fast");

    // $(".red-box").fadeOut(2000);
    // $(".green-box").fadeOut(2000);
    // $(".red-box").fadeIn(1000);
    // $(".red-box").fadeTo(1000, 0.5);

    $(".red-box").fadeTo(3000, 0.2);
    $(".gree-box").fadeTo(2000, 0.5);
    $(".blue-box").fadeTo(1000, 0.8);

    $(".blue-box").fadeToggle();
    $(".blue-box").fadeToggle();




});