$(function() {
    // $(".green-box").fadeOut(2000);
    // $(".green-box").fadeTo(1000, 0);

    // $(".blue-box").hide();
    // $(".blue-box").show(3000);
    // $(".blue-box").toggle(3000);

    // $(".blue-box").slideUp(2000);
    // $(".blue-box").slideDown(2000);

    // $(".blue-box").slideToggle(2000);

    $("p").hide();
    $("p").slideDown(2000);





  });