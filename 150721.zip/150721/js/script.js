$(function() {
    // $(".blue-box").animate({
    //     "margin-left": "+=200px"
    // }, 2000, "linear");

    // $(".blue-box").animate({
    //     "margin-left": "-=200px"
    // }, 2000, "linear");

    $(".blue-box").animate({
        "margin-left": "+=200px",
        opacity: 0,
        height: "50px",
        width: "50px",
        marginTop: "100px"
    }, 2000, "linear");

    $("p").animate({
        "font-size": "20px",
      }, 1000);


  });