<?php
// if condition
// $x = 50;

// if ($x < "40") {
//     echo "X is greater";
// }


// $x = 30;
// $y = 20;
// if ($x < $y)
//     echo "Y is greater";
// else
//     echo "X is Greater ";

// The if...elseif...else Statement

// $day = "Sat";
// if ($day == "Fri")
//     echo "Have a nice Friday ";

// elseif ($day == "Sun")
//     echo "Have a happy Sunday";

// else
//     echo "Have a good day";

// SWITCH STATEMENT IN PHP

$day = "Fri";
switch ($day) {
    case "Sun":
        echo "Today is Sunday";
        break;
    case "Wed":
        echo "Today is Wednesday ";
        break;
    case "Tue":
        echo "Today is Tuesday";
        break;
    case "Thu":
        echo "Today is Thursday";
        break;
    case "Fri":
        echo "Today is Friday";
        break;
    case "Sat":
        echo "Today is Saturday";
        break;
    case "Sun":
        echo "Today is Sunday";
        break;
    default:
        echo "Which day is this ?";
}
