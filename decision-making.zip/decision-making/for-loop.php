<!-- for loop
Loop through the block of code specified number of time execute. -->
<?php
// for ($i = 0; $i < 5; $i++) {
//     echo "The numbers are: " . $i . "<br>";
// }


// Array with For Loop
$letters = array();
for ($i = 'A'; $i != 'AA'; $i++) {
    array_push($letters, $i);
    echo $i . "<br>";
    $var = print_r($letters, true);
    echo $var;
}
